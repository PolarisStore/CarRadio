
RegisterNetEvent('key_carplay:syncmusic')

AddEventHandler('key_carplay:syncmusic', function(peds, vehNet, data)

    local veh = NetworkGetEntityFromNetworkId(vehNet)

	if veh ~= 0 then

        for k, v in pairs(peds) do
            TriggerClientEvent("key_carplay:playsound", v, data)

        end

	end

end)


